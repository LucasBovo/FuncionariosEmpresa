package org.example;

public class FuncionariosGerais {
    String nome;
    String cpf;
}
